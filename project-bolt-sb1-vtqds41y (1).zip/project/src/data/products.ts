export const products = [
  {
    id: 1,
    name: "Traditional Banarasi Silk Saree",
    price: 5999,
    description: "Handwoven Banarasi silk saree with intricate zari work",
    image: "https://images.unsplash.com/photo-1610030469629-df637062329f?w=500&q=80",
    category: "Sarees",
    rating: 4.8
  },
  {
    id: 2,
    name: "Copper Water Dispenser",
    price: 1499,
    description: "Traditional copper water pot with tap for health benefits",
    image: "https://images.unsplash.com/photo-1597666716471-f7ba0842c162?w=500&q=80",
    category: "Home & Living",
    rating: 4.5
  },
  {
    id: 3,
    name: "OnePlus 11R 5G",
    price: 39999,
    description: "Powerful 5G smartphone with Snapdragon processor",
    image: "https://images.unsplash.com/photo-1678652197831-2d180705cd2c?w=500&q=80",
    category: "Electronics",
    rating: 4.9
  },
  {
    id: 4,
    name: "Handcrafted Brass Diya Set",
    price: 899,
    description: "Set of 5 traditional brass diyas for puja",
    image: "https://images.unsplash.com/photo-1604423043492-41303788de80?w=500&q=80",
    category: "Puja Items",
    rating: 4.8
  },
  {
    id: 5,
    name: "Organic Ayurvedic Tea Set",
    price: 499,
    description: "Collection of traditional wellness teas",
    image: "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=500&q=80",
    category: "Ayurveda",
    rating: 4.6
  },
  {
    id: 6,
    name: "Handloom Cotton Kurta",
    price: 1299,
    description: "Men's traditional handloom cotton kurta",
    image: "https://images.unsplash.com/photo-1597983073493-88cd35cf93b0?w=500&q=80",
    category: "Men's Fashion",
    rating: 4.7
  },
  {
    id: 7,
    name: "Samsung Galaxy S23 Ultra",
    price: 124999,
    description: "Premium Android phone with 200MP camera",
    image: "https://images.unsplash.com/photo-1678911820864-e7a5d5407693?w=500&q=80",
    category: "Electronics",
    rating: 4.8
  },
  {
    id: 8,
    name: "Handcrafted Wooden Chess Set",
    price: 2499,
    description: "Traditional wooden chess set with intricate carvings",
    image: "https://images.unsplash.com/photo-1586165368502-1bad197a6461?w=500&q=80",
    category: "Home & Living",
    rating: 4.7
  },
  {
    id: 9,
    name: "Kolhapuri Leather Chappal",
    price: 999,
    description: "Authentic handcrafted leather Kolhapuri sandals",
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=500&q=80",
    category: "Footwear",
    rating: 4.7
  },
  {
    id: 10,
    name: "Madhubani Painting",
    price: 3999,
    description: "Traditional Madhubani art on handmade paper",
    image: "https://images.unsplash.com/photo-1582457601528-849a66f9fc6e?w=500&q=80",
    category: "Art & Decor",
    rating: 4.9
  },
  {
    id: 11,
    name: "Spice Box (Masala Dabba)",
    price: 1299,
    description: "Traditional stainless steel spice box with 7 compartments",
    image: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=500&q=80",
    category: "Kitchen",
    rating: 4.8
  },
  {
    id: 12,
    name: "Pashmina Shawl",
    price: 4999,
    description: "Pure Pashmina shawl with traditional embroidery",
    image: "https://images.unsplash.com/photo-1601244005535-a48d21d951ac?w=500&q=80",
    category: "Women's Fashion",
    rating: 4.9
  }
];

export const categories = [
  "All",
  "Sarees",
  "Men's Fashion",
  "Women's Fashion",
  "Electronics",
  "Puja Items",
  "Ayurveda",
  "Kitchen",
  "Home & Living",
  "Art & Decor",
  "Footwear"
];