import React, { useState } from 'react';
import { ShoppingBag, Search } from 'lucide-react';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';
import { ProductCard } from './components/ProductCard';
import { Cart } from './components/Cart';
import { products, categories } from './data/products';

function App() {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <CartProvider>
      <WishlistProvider>
        <div className="min-h-screen bg-orange-50">
          {/* Header */}
          <header className="bg-white shadow-sm sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 py-4">
              <div className="flex justify-between items-center mb-4">
                <h1 className="text-2xl font-bold text-orange-600 flex items-center gap-2">
                  <ShoppingBag className="text-orange-600" />
                  IndiBazaar
                </h1>
                <button
                  onClick={() => setIsCartOpen(!isCartOpen)}
                  className="p-2 hover:bg-orange-100 rounded-full relative text-orange-600"
                >
                  <ShoppingBag size={24} />
                </button>
              </div>
              
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-orange-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 bg-orange-50"
                />
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="max-w-7xl mx-auto px-4 py-8">
            {/* Categories */}
            <div className="mb-8 flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-orange-600 text-white'
                      : 'bg-white text-gray-700 hover:bg-orange-100'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
              {/* Products Grid */}
              <div className={`grid grid-cols-1 md:grid-cols-2 ${isCartOpen ? 'lg:grid-cols-2' : 'lg:grid-cols-3'} gap-6 ${isCartOpen ? 'lg:w-2/3' : 'w-full'}`}>
                {filteredProducts.length > 0 ? (
                  filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))
                ) : (
                  <div className="col-span-full text-center py-8">
                    <p className="text-gray-500">No products found matching your criteria</p>
                  </div>
                )}
              </div>

              {/* Cart Sidebar */}
              {isCartOpen && (
                <div className="w-full lg:w-1/3 bg-white p-6 rounded-lg shadow-lg h-fit lg:sticky lg:top-32">
                  <h2 className="text-xl font-semibold mb-4 text-orange-600">Your Cart</h2>
                  <Cart />
                </div>
              )}
            </div>
          </main>
        </div>
      </WishlistProvider>
    </CartProvider>
  );
}

export default App;